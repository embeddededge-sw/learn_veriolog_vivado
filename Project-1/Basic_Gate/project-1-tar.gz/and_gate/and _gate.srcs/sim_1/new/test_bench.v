`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/23/2026 01:57:31 PM
// Design Name: 
// Module Name: test_bench
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module test_bench;

//declare inputs and outputs for our simulation
reg input1t, input2t;
wire output1t, output2t;

nand_or_gate UUT(
                .input1(input1t),
                .input2(input2t),
                .output1(output1t),
                .output2(output2t)
                );
                
//simulation
initial begin

//initialise
input1t = 0;
input2t = 0;

#100

//here we simulate
repeat(8)

    begin 
        #100 {input1t, input2t} = {input1t, input2t} + 1'b1;
    end

end

endmodule
