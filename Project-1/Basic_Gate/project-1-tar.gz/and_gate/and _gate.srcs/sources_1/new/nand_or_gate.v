`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 08/23/2026 12:59:52 PM
// Design Name: 
// Module Name: nand_or_gate
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module nand_or_gate(input1, input2, output1, output2);

//declare inputs and outputs
input input1, input2;
output output1, output2;

//AND gate
assign output1 = input1 && input2;

//OR gate
assign output2 = input1 || input2;


endmodule
